# Extraction Examples: AI Output from Your Safety SOPs

**Project:** AI Document Intelligence Pipeline  
**Date:** January 1, 2025  
**Purpose:** Show exactly what the AI (Bedrock) will extract from your documents  

---

## 📋 Overview

This document shows **realistic examples** of what AWS Bedrock (Claude AI) will extract from your 3 chemical safety SOPs.

**Your Test Documents:**
1. `__SAFETY_SOP.pdf` (Full detailed SOP - 5 pages)
2. `Simplified_Safety_Guide.pdf` (Simplified version - 4 pages)
3. `Technician_Quick_Sheet.pdf` (Quick reference - 2 pages)

---

## 🎯 What We're Extracting

For each document, the AI will extract:
- **Document ID** - Unique identifier
- **Title** - Document name
- **Summary** - 2-3 sentence overview
- **Key Steps** - Main procedural steps
- **PPE Required** - Safety equipment needed
- **Warnings** - Critical safety warnings
- **Emergency Info** - Emergency procedures/contacts

---

## 📄 Example 1: Full Safety SOP

### Input Document: `__SAFETY_SOP.pdf`

**What the user uploads:**
```
SAFETY SOP – CHEMICAL HANDLING & DILUTION

Company: MetroClean Facilities Group
Document ID: SOP-SAF-001
Title: Chemical Handling & Dilution Safety
Department: Operations / Janitorial Services
Effective Date: 2025-01-01

1. PURPOSE
The purpose of this Standard Operating Procedure (SOP) is to...

3. RESPONSIBILITIES
3.1 Technicians
• Follow all steps in this SOP when handling chemicals
• Wear required personal protective equipment (PPE)
• Report spills, leaks, or unsafe conditions...

4. REQUIRED PPE
• Chemical-resistant gloves
• Safety glasses or goggles
• Slip-resistant, closed-toe shoes
• Long sleeves or coveralls (recommended)

(continues for 5 pages...)
```

### AI Extraction Output (JSON):

```json
{
  "document_id": "SOP-SAF-001",
  "document_name": "__SAFETY_SOP.pdf",
  "document_type": "Safety SOP",
  "upload_timestamp": "2025-01-01T14:30:00Z",
  "processed_timestamp": "2025-01-01T14:30:05Z",
  "s3_key": "uploads/__SAFETY_SOP.pdf",
  
  "title": "Chemical Handling & Dilution Safety",
  
  "summary": "Standard Operating Procedure for safely receiving, storing, diluting, and using cleaning chemicals at MetroClean job sites. Establishes practices to minimize risk of injury, property damage, and environmental harm. Applies to all technicians, leads, and supervisors handling concentrated and ready-to-use cleaning products.",
  
  "key_steps": [
    "Put on all required PPE before handling chemicals",
    "Only use MetroClean-approved chemicals in original containers",
    "Store chemicals in designated closet or storage room with containers tightly closed",
    "Label all secondary containers with product name, dilution ratio, and hazard",
    "For wall-mounted dilution station: verify correct product, place container under nozzle, select dilution setting, activate and fill",
    "For manual dilution: fill container with water first, measure concentrate, slowly add concentrate to water (never reverse), mix gently, label container",
    "Use chemicals per product instructions; avoid spraying near electrical equipment",
    "For small spills: put on PPE, contain with absorbent pads, wipe up and bag waste",
    "For large spills: stop work, evacuate if fumes present, notify supervisor, do not clean without authorization",
    "For skin contact: remove clothing, rinse 15 minutes, report incident",
    "For eye contact: go to eyewash station, flush 15 minutes, seek medical help",
    "For inhalation: move to fresh air, call emergency if symptoms persist"
  ],
  
  "ppe_required": [
    "Chemical-resistant gloves",
    "Safety glasses or goggles",
    "Slip-resistant, closed-toe shoes",
    "Long sleeves or coveralls (recommended for bulk mixing)",
    "Face shield or respirator (if required by SDS)"
  ],
  
  "warnings": [
    "NEVER mix different chemicals together (e.g., bleach and acid)",
    "Never store chemicals near food or break areas",
    "Never store chemicals in public restrooms",
    "Never store chemicals in direct sunlight or above 75°F when avoidable",
    "Never add water to concentrate - always add concentrate to water",
    "Do not spray near electrical panels, outlets, or equipment",
    "Evacuate area if strong fumes or eye/respiratory irritation occurs",
    "Do not attempt large spill cleanup without authorization",
    "Unlabeled or unauthorized chemicals are strictly prohibited"
  ],
  
  "emergency_info": "Contact supervisor immediately for large spills or exposure incidents. For persistent symptoms (coughing, dizziness, difficulty breathing), call emergency services. Eyewash station must be used for 15 minutes continuous flush for eye exposure. All incidents must be documented.",
  
  "dilution_requirements": {
    "general_rule": "Use cold or room-temperature water only",
    "never_do": "Never add water to concentrate",
    "always_do": "Always add concentrate to water",
    "example_ratio": "MC-Disinfectant 64: 1 ounce concentrate per 1 gallon water (1:128)"
  },
  
  "training_requirements": [
    "Initial training required before working with chemicals",
    "Refresher training annually or after product changes",
    "Must cover: reading labels and SDS, required PPE, dilution procedures, spill response, exposure actions"
  ],
  
  "records_retention": "Training records, incident reports, and SDS library must be kept for minimum 3 years",
  
  "processing_status": "completed",
  "bedrock_model": "claude-3-haiku",
  "processing_duration_ms": 4800
}
```

---

## 📄 Example 2: Simplified Safety Guide

### Input Document: `Simplified_Safety_Guide.pdf`

**What the user uploads:**
```
Simplified Safety Guide – Chemical Handling & Dilution

I. Purpose and Scope
This guide sets the rules for safely receiving, storing, mixing, and using 
cleaning chemicals at all MetroClean job sites...

III. Required Safety Gear (PPE)
You must wear the following gear any time you handle, mix, or move 
concentrated chemicals:
• Chemical-resistant gloves.
• Safety glasses or goggles.
• Slip-resistant, closed-toe shoes...

(4 pages total, simplified language)
```

### AI Extraction Output (JSON):

```json
{
  "document_id": "SIMPLE-SAF-001",
  "document_name": "Simplified_Safety_Guide.pdf",
  "document_type": "Simplified Safety Guide",
  "upload_timestamp": "2025-01-01T14:32:00Z",
  "processed_timestamp": "2025-01-01T14:32:04Z",
  "s3_key": "uploads/Simplified_Safety_Guide.pdf",
  
  "title": "Simplified Safety Guide – Chemical Handling & Dilution",
  
  "summary": "Simplified safety rules for receiving, storing, mixing, and using cleaning chemicals at MetroClean sites. Designed to prevent injury, property damage, and environmental harm. Written in clear, accessible language for all technician skill levels.",
  
  "key_steps": [
    "Follow every step in this Safety Guide",
    "Wear correct PPE: gloves, goggles, closed-toe shoes",
    "Only use MetroClean-approved chemicals",
    "Store chemicals in designated closets with containers closed",
    "Label secondary containers with name, ratio, and hazard",
    "Read product label and SDS before first use",
    "Use dilution station: check product, place container, select ratio, fill",
    "Manual mixing: water first, then add concentrate slowly",
    "Report all spills or unsafe conditions immediately",
    "Small spills: PPE on, contain with pads, bag waste",
    "Large spills: stop work, evacuate if fumes, notify supervisor",
    "Skin contact: rinse 15 minutes under water",
    "Eye contact: eyewash station 15 minutes",
    "Breathing fumes: move to fresh air, call emergency if needed"
  ],
  
  "ppe_required": [
    "Chemical-resistant gloves",
    "Safety glasses or goggles",
    "Slip-resistant, closed-toe shoes",
    "Long sleeves or coveralls (recommended)"
  ],
  
  "warnings": [
    "NEVER mix different chemicals (e.g., bleach and acid)",
    "Never store near food or break areas",
    "Never store in public restrooms",
    "Never store in direct sunlight or above 75°F",
    "Check SDS for additional gear requirements (face shield/respirator)",
    "Do not spray near electrical equipment"
  ],
  
  "emergency_info": "Report spills/leaks to supervisor right away. For skin: rinse 15 min. For eyes: eyewash 15 min, get medical help. For fumes: fresh air, call emergency if symptoms continue.",
  
  "approved_chemicals_examples": [
    "MC-Neutral Floor Cleaner",
    "MC-Disinfectant 64"
  ],
  
  "reading_level": "8th grade",
  "target_audience": "All MetroClean technicians, leads, and supervisors",
  
  "processing_status": "completed",
  "bedrock_model": "claude-3-haiku",
  "processing_duration_ms": 3200
}
```

---

## 📄 Example 3: Technician Quick Sheet

### Input Document: `Technician_Quick_Sheet.pdf`

**What the user uploads:**
```
Technician Quick Sheet — Chemical Handling & Dilution

I. Essential Safety Rules (Must Do)
• Always wear required PPE.
• Follow all steps in this procedure.
• NEVER mix different chemicals (e.g., bleach + acid).
• Only use MetroClean-approved chemicals...

II. Required Safety Gear (PPE)
• Chemical-resistant gloves.
• Safety glasses or goggles...

IV. Emergency Response Steps
(Quick reference table with actions)

(2 pages total, bullet points, quick reference)
```

### AI Extraction Output (JSON):

```json
{
  "document_id": "QUICK-SAF-001",
  "document_name": "Technician_Quick_Sheet.pdf",
  "document_type": "Quick Reference Guide",
  "upload_timestamp": "2025-01-01T14:34:00Z",
  "processed_timestamp": "2025-01-01T14:34:02Z",
  "s3_key": "uploads/Technician_Quick_Sheet.pdf",
  
  "title": "Technician Quick Sheet — Chemical Handling & Dilution",
  
  "summary": "One-page quick reference for essential chemical handling safety rules. Condensed version of full SOP with must-know PPE requirements, dilution ratios, and emergency response steps for on-the-job reference.",
  
  "key_steps": [
    "Always wear required PPE",
    "Follow all procedure steps",
    "NEVER mix different chemicals",
    "Only use approved MetroClean chemicals",
    "Report all spills/leaks/unsafe conditions immediately",
    "Review product label before first use",
    "Use cold/room-temp water only",
    "Always add concentrate to water (never reverse)",
    "Containers must be labeled with name, ratio, hazard"
  ],
  
  "ppe_required": [
    "Chemical-resistant gloves",
    "Safety glasses or goggles",
    "Slip-resistant, closed-toe shoes",
    "Check SDS for additional needs (face shield, respirator)"
  ],
  
  "warnings": [
    "NEVER mix different chemicals (e.g., bleach + acid)",
    "Never use unauthorized chemicals"
  ],
  
  "emergency_procedures": {
    "skin_contact": "Remove clothing. Rinse skin with running water for 15 minutes. Report incident.",
    "eye_contact": "Go to eyewash station immediately. Flush eyes continuously for 15 minutes. Seek medical assistance.",
    "inhalation": "Move to fresh air immediately. If symptoms continue, call emergency services.",
    "small_spill": "Put on PPE. Contain spill with absorbent pads. Wipe up and bag waste.",
    "large_spill": "Stop work immediately. Evacuate area if fumes cause irritation. Notify supervisor. Do not clean without authorization."
  },
  
  "dilution_example": "MC-Disinfectant 64: 1 ounce of concentrate per 1 gallon of water (1:128)",
  
  "document_format": "Quick reference table and bullet points",
  "page_count": 2,
  "designed_for": "Lamination and on-site posting",
  
  "processing_status": "completed",
  "bedrock_model": "claude-3-haiku",
  "processing_duration_ms": 2100
}
```

---

## 🔍 Comparison: Same Content, Different Formats

Notice how the AI extracts the **same core information** from all 3 documents, but adjusts to the format:

| Field | Full SOP | Simplified Guide | Quick Sheet |
|-------|----------|------------------|-------------|
| **Detail Level** | Comprehensive | Moderate | Minimal |
| **Key Steps** | 12 detailed steps | 14 simplified steps | 9 essential steps |
| **Warnings** | 9 specific warnings | 6 key warnings | 2 critical warnings |
| **PPE Items** | 5 items with details | 4 items | 4 items |
| **Processing Time** | ~4.8 seconds | ~3.2 seconds | ~2.1 seconds |

**This demonstrates the AI's ability to:**
- Extract relevant information regardless of format
- Adapt to different document structures
- Maintain consistency across related documents
- Provide appropriate level of detail

---

## 📊 DynamoDB Table Design

### Table Name: `ProcessedDocuments`

**Primary Key:**
- **Partition Key:** `document_id` (string)
- **Sort Key:** `processed_timestamp` (string, ISO 8601 format)

**Why this design?**
- Fast lookups by document ID
- Can track multiple versions (if same doc processed multiple times)
- Sort by timestamp shows processing history

### Secondary Indexes (Optional):

**GSI-1: By Document Type**
- **Partition Key:** `document_type`
- **Sort Key:** `processed_timestamp`
- **Use Case:** "Show me all Safety SOPs" or "Show me all Quick Sheets"

**GSI-2: By Upload Date**
- **Partition Key:** `upload_date` (YYYY-MM-DD)
- **Sort Key:** `processed_timestamp`
- **Use Case:** "Show me all documents uploaded on 2025-01-01"

### Example Query Patterns:

**Query 1: Get specific document**
```python
response = dynamodb.get_item(
    TableName='ProcessedDocuments',
    Key={
        'document_id': 'SOP-SAF-001',
        'processed_timestamp': '2025-01-01T14:30:05Z'
    }
)
```

**Query 2: Get all Safety SOPs**
```python
response = dynamodb.query(
    TableName='ProcessedDocuments',
    IndexName='DocumentTypeIndex',
    KeyConditionExpression='document_type = :type',
    ExpressionAttributeValues={':type': 'Safety SOP'}
)
```

**Query 3: Search for keyword in warnings**
```python
response = dynamodb.scan(
    TableName='ProcessedDocuments',
    FilterExpression='contains(warnings, :keyword)',
    ExpressionAttributeValues={':keyword': 'bleach'}
)
```

---

## 🎨 API Response Examples

### GET /documents

**Request:**
```bash
GET https://api-gateway-url.com/prod/documents?limit=10
```

**Response:**
```json
{
  "count": 3,
  "documents": [
    {
      "document_id": "SOP-SAF-001",
      "title": "Chemical Handling & Dilution Safety",
      "document_type": "Safety SOP",
      "processed_timestamp": "2025-01-01T14:30:05Z",
      "summary": "Standard Operating Procedure for safely..."
    },
    {
      "document_id": "SIMPLE-SAF-001",
      "title": "Simplified Safety Guide",
      "document_type": "Simplified Safety Guide",
      "processed_timestamp": "2025-01-01T14:32:04Z",
      "summary": "Simplified safety rules for receiving..."
    },
    {
      "document_id": "QUICK-SAF-001",
      "title": "Technician Quick Sheet",
      "document_type": "Quick Reference Guide",
      "processed_timestamp": "2025-01-01T14:34:02Z",
      "summary": "One-page quick reference for essential..."
    }
  ]
}
```

### GET /documents/{id}

**Request:**
```bash
GET https://api-gateway-url.com/prod/documents/SOP-SAF-001
```

**Response:**
```json
{
  "document_id": "SOP-SAF-001",
  "title": "Chemical Handling & Dilution Safety",
  "summary": "Standard Operating Procedure for safely...",
  "key_steps": [
    "Put on all required PPE before handling chemicals",
    "Only use MetroClean-approved chemicals...",
    ...
  ],
  "ppe_required": [
    "Chemical-resistant gloves",
    ...
  ],
  "warnings": [
    "NEVER mix different chemicals together",
    ...
  ],
  "emergency_info": "Contact supervisor immediately...",
  "processed_timestamp": "2025-01-01T14:30:05Z"
}
```

### GET /search?query=PPE

**Request:**
```bash
GET https://api-gateway-url.com/prod/search?query=PPE
```

**Response:**
```json
{
  "query": "PPE",
  "results_count": 3,
  "results": [
    {
      "document_id": "SOP-SAF-001",
      "title": "Chemical Handling & Dilution Safety",
      "matched_field": "ppe_required",
      "matched_content": [
        "Chemical-resistant gloves",
        "Safety glasses or goggles",
        "Slip-resistant, closed-toe shoes"
      ]
    },
    {
      "document_id": "SIMPLE-SAF-001",
      "title": "Simplified Safety Guide",
      "matched_field": "key_steps",
      "matched_content": "Wear correct PPE: gloves, goggles, closed-toe shoes"
    },
    {
      "document_id": "QUICK-SAF-001",
      "title": "Technician Quick Sheet",
      "matched_field": "ppe_required",
      "matched_content": [
        "Chemical-resistant gloves",
        "Safety glasses or goggles"
      ]
    }
  ]
}
```

---

## 🧪 Testing Strategy

### Phase 1: Single Document Test
1. Upload `__SAFETY_SOP.pdf`
2. Verify Lambda triggers
3. Check CloudWatch logs
4. Verify DynamoDB entry
5. Query via API

### Phase 2: Multiple Document Test
1. Upload all 3 documents
2. Verify all process correctly
3. Test API list endpoint
4. Test search functionality

### Phase 3: Error Handling
1. Upload corrupted PDF
2. Upload non-PDF file
3. Upload very large file (>10MB)
4. Verify error logging and graceful failure

---

## 💡 Prompt Engineering Notes

The extraction quality depends on the **prompt** we send to Bedrock. Here's what makes a good extraction prompt:

### Key Elements:
1. **Clear Role:** "You are an expert at extracting structured data..."
2. **Specific Instructions:** List exactly what to extract
3. **Output Format:** "Return ONLY valid JSON in this format..."
4. **Examples (optional):** Show sample input/output
5. **Constraints:** "Do not include commentary or explanations"

### Sample Prompt Structure:
```
You are an expert at extracting structured data from safety documents.

Read the following document and extract:
1. Document title and ID (if present)
2. A concise summary (2-3 sentences maximum)
3. Key procedural steps (as numbered list)
4. Required PPE (as list)
5. Safety warnings (as list)
6. Emergency contact information or procedures

Return ONLY valid JSON in this exact format:
{
  "document_id": "...",
  "title": "...",
  "summary": "...",
  "key_steps": [...],
  "ppe_required": [...],
  "warnings": [...],
  "emergency_info": "..."
}

Document text:
{document_text}

Remember: Return ONLY the JSON object, no markdown, no explanations.
```

---

## 🎯 Success Metrics

**We'll know the extraction is working when:**
- ✅ All 3 documents process without errors
- ✅ Extracted JSON is valid and parseable
- ✅ Key information matches source documents
- ✅ PPE lists are complete and accurate
- ✅ Warnings are captured correctly
- ✅ Processing time is under 10 seconds per document
- ✅ DynamoDB queries return correct results
- ✅ API search finds relevant documents

---

## 📝 Notes for Implementation

### When Building the Lambda Function:
1. **Read document from S3** - Use boto3 s3.get_object()
2. **Extract text from PDF** - Use PyPDF2 or pdfplumber
3. **Construct prompt** - Insert document text into template
4. **Call Bedrock** - Use boto3 bedrock-runtime.invoke_model()
5. **Parse response** - Extract JSON from AI response
6. **Add metadata** - Timestamps, S3 key, processing status
7. **Store in DynamoDB** - Use boto3 dynamodb.put_item()
8. **Error handling** - Try/catch for network, parsing, validation

### Common Issues to Watch For:
- **Large documents** - May exceed token limits (chunk if needed)
- **PDF extraction errors** - Some PDFs have images/tables (handle gracefully)
- **Invalid JSON** - AI sometimes adds markdown (strip ```json fences)
- **Rate limits** - Bedrock has request/minute limits (add retry logic)

---

## 🔗 Related Documentation

- **Architecture:** `architecture-design.md`
- **Session Log:** `Day-01-Session-Log.md`
- **AI Workflow:** `ai-copilot-workflow.md`

---

*These examples represent realistic output from AWS Bedrock processing your actual safety SOP documents. Actual results may vary slightly based on prompt engineering and model version.*
