# Architecture Design: AI Document Intelligence Pipeline

**Project:** AI-Powered Document Intelligence Pipeline  
**Date:** January 1, 2025  
**Version:** 1.0  
**Status:** Planning Phase  

---

## 🎯 System Overview

This is a **serverless, event-driven AI document processing system** that automatically extracts structured data from unstructured documents (PDFs, DOCX, TXT) using AWS Bedrock and stores results in a queryable database.

### High-Level Flow

```
📄 User uploads document to S3
         ↓
⚡ S3 Event automatically triggers Lambda
         ↓
🤖 Lambda sends document to Bedrock AI
         ↓
🧠 AI extracts structured JSON data
         ↓
💾 Lambda stores results in DynamoDB
         ↓
🌐 API Gateway provides query interface
```

---

## 🏗️ Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                         USER INTERACTION                         │
└────────────┬────────────────────────────────────┬───────────────┘
             │                                     │
             ▼                                     ▼
    ┌────────────────┐                   ┌────────────────┐
    │   Upload PDF   │                   │  Query Results │
    │   via Console  │                   │   via API      │
    │   or CLI       │                   │   Gateway      │
    └────────┬───────┘                   └────────┬───────┘
             │                                     │
             ▼                                     ▼
    ┌─────────────────────────────────────────────────────────┐
    │                    AWS CLOUD                             │
    │                                                          │
    │  ┌──────────────────────────────────────────────────┐  │
    │  │              S3 BUCKET (Storage Layer)            │  │
    │  │  - Stores uploaded documents                      │  │
    │  │  - Triggers Lambda on new uploads                 │  │
    │  │  - Bucket: doc-intelligence-uploads               │  │
    │  └────────────────┬─────────────────────────────────┘  │
    │                   │                                     │
    │                   │ (S3 Event Notification)             │
    │                   ▼                                     │
    │  ┌──────────────────────────────────────────────────┐  │
    │  │       LAMBDA FUNCTION (Processing Layer)          │  │
    │  │  - Runtime: Python 3.11                           │  │
    │  │  - Reads document from S3                         │  │
    │  │  - Calls Bedrock API                              │  │
    │  │  - Parses AI response                             │  │
    │  │  - Stores in DynamoDB                             │  │
    │  │  - Function: DocumentProcessorFunction            │  │
    │  └────┬─────────────────────────┬────────────────────┘  │
    │       │                         │                        │
    │       │                         │                        │
    │       ▼                         ▼                        │
    │  ┌──────────────┐      ┌───────────────────────┐       │
    │  │   BEDROCK    │      │     DYNAMODB          │       │
    │  │   (AI Layer) │      │  (Storage Layer)      │       │
    │  │              │      │                       │       │
    │  │ Model:       │      │ Table:                │       │
    │  │ Claude 3     │      │ ProcessedDocuments    │       │
    │  │ Haiku        │      │                       │       │
    │  │              │      │ Stores:               │       │
    │  │ Extracts:    │      │ - Document metadata   │       │
    │  │ - Summary    │      │ - AI-extracted data   │       │
    │  │ - Key steps  │      │ - Timestamps          │       │
    │  │ - Warnings   │      │ - Search indexes      │       │
    │  │ - PPE        │      │                       │       │
    │  └──────────────┘      └───────────┬───────────┘       │
    │                                     │                   │
    │                                     │                   │
    │                                     ▼                   │
    │  ┌──────────────────────────────────────────────────┐  │
    │  │       API GATEWAY (Query Layer)                   │  │
    │  │                                                   │  │
    │  │  Endpoints:                                       │  │
    │  │  GET  /documents          (list all)             │  │
    │  │  GET  /documents/{id}     (get specific)         │  │
    │  │  GET  /search?query=PPE   (search)               │  │
    │  │                                                   │  │
    │  │  Connected to Query Lambda Functions             │  │
    │  └──────────────────────────────────────────────────┘  │
    │                                                          │
    └──────────────────────────────────────────────────────────┘
```

---

## 🧩 Component Breakdown

### 1. Amazon S3 (Storage)

**Purpose:** Document upload and storage  
**Type:** Object storage  
**Configuration:**
- **Bucket Name:** `doc-intelligence-uploads-[your-id]`
- **Event Notifications:** Trigger Lambda on `s3:ObjectCreated:*`
- **Supported Formats:** PDF, DOCX, TXT
- **Lifecycle:** Documents retained for 90 days (optional)

**Think of it as:** Google Drive for documents, but with automatic processing triggers

**Why we need it:**
- Scalable storage (handles 1 file or 1 million)
- Event-driven (automatically notifies Lambda)
- Durable (99.999999999% durability)
- Cost-effective (pay only for what you store)

---

### 2. AWS Lambda (Compute)

**Purpose:** Serverless document processor  
**Type:** Function as a Service (FaaS)  
**Configuration:**
- **Runtime:** Python 3.11
- **Memory:** 512 MB (adjustable based on document size)
- **Timeout:** 5 minutes (AI calls can take time)
- **Trigger:** S3 event notification

**What it does:**
1. Receives S3 event (new document uploaded)
2. Downloads document from S3
3. Extracts text from document
4. Constructs prompt for Bedrock
5. Calls Bedrock API
6. Parses AI response (JSON)
7. Stores structured data in DynamoDB
8. Returns success/failure

**Think of it as:** A robot worker that wakes up when a document arrives, processes it, and goes back to sleep

**Why we need it:**
- No servers to manage (fully managed)
- Automatic scaling (handles 1 or 1000 concurrent uploads)
- Pay-per-use (only charged when processing)
- Event-driven (perfect for document triggers)

---

### 3. AWS Bedrock (AI)

**Purpose:** AI-powered document understanding  
**Type:** Managed AI service (LLM API)  
**Configuration:**
- **Model:** `anthropic.claude-3-haiku-20240307-v1:0`
- **Max Tokens:** 2000 (for response)
- **Temperature:** 0.3 (more deterministic)

**What it does:**
1. Receives document text + extraction prompt from Lambda
2. Reads and understands the document
3. Extracts structured information:
   - Document summary
   - Key procedural steps
   - Safety warnings
   - PPE requirements
   - Emergency procedures
4. Returns data as JSON

**Sample Prompt We'll Use:**
```
You are an expert at extracting structured data from safety documents.

Read the following document and extract:
1. Document title and ID
2. A concise summary (2-3 sentences)
3. Key procedural steps (numbered list)
4. Required PPE (list)
5. Safety warnings (list)
6. Emergency contact information

Return ONLY valid JSON in this format:
{
  "document_id": "...",
  "title": "...",
  "summary": "...",
  "key_steps": [...],
  "ppe_required": [...],
  "warnings": [...],
  "emergency_info": "..."
}

Document:
{document_text}
```

**Think of it as:** A highly skilled analyst who reads documents and extracts key information instantly

**Why we need it:**
- Natural language understanding (reads like a human)
- Structured output (returns clean JSON)
- Scalable (handles any document type)
- No model training needed (foundation model)

---

### 4. Amazon DynamoDB (Database)

**Purpose:** Store AI-extracted data  
**Type:** NoSQL database  
**Configuration:**
- **Table Name:** `ProcessedDocuments`
- **Partition Key:** `document_id` (string)
- **Sort Key:** `processed_timestamp` (string - ISO format)
- **Billing Mode:** Pay-per-request (no capacity planning)

**Schema Design:**
```json
{
  "document_id": "SOP-SAF-001",
  "document_name": "__SAFETY_SOP.pdf",
  "document_type": "Safety SOP",
  "upload_timestamp": "2025-01-01T10:00:00Z",
  "processed_timestamp": "2025-01-01T10:00:05Z",
  "s3_key": "uploads/__SAFETY_SOP.pdf",
  "title": "Chemical Handling & Dilution Safety",
  "summary": "Standard procedures for safely handling...",
  "key_steps": [
    "Wear required PPE at all times",
    "Only use approved MetroClean chemicals",
    "Add concentrate to water, never reverse"
  ],
  "ppe_required": [
    "Chemical-resistant gloves",
    "Safety glasses or goggles",
    "Slip-resistant closed-toe shoes"
  ],
  "warnings": [
    "NEVER mix different chemicals together",
    "Never store chemicals near food areas",
    "Evacuate if strong fumes occur"
  ],
  "emergency_info": "Contact supervisor immediately for large spills",
  "processing_status": "completed",
  "bedrock_model": "claude-3-haiku",
  "processing_duration_ms": 4500
}
```

**Think of it as:** A fast, searchable filing cabinet for all processed documents

**Why we need it:**
- Fast queries (millisecond response times)
- Flexible schema (can add fields later)
- Scalable (handles millions of documents)
- Cost-effective (pay per read/write)

---

### 5. Amazon API Gateway (API Layer)

**Purpose:** RESTful API for querying results  
**Type:** Managed API service  
**Configuration:**
- **Type:** REST API
- **Stage:** `prod`
- **Authentication:** IAM (optional: API keys)

**Endpoints We'll Create:**

#### GET /documents
**Purpose:** List all processed documents  
**Query Parameters:**
- `limit` (optional): Number of results (default: 20)
- `type` (optional): Filter by document_type

**Response:**
```json
{
  "count": 3,
  "documents": [
    {
      "document_id": "SOP-SAF-001",
      "title": "Chemical Handling Safety",
      "processed_timestamp": "2025-01-01T10:00:05Z"
    },
    ...
  ]
}
```

#### GET /documents/{id}
**Purpose:** Get specific document details  
**Path Parameter:** `document_id`

**Response:**
```json
{
  "document_id": "SOP-SAF-001",
  "title": "Chemical Handling & Dilution Safety",
  "summary": "...",
  "key_steps": [...],
  "ppe_required": [...],
  "warnings": [...]
}
```

#### GET /search
**Purpose:** Search documents by keyword  
**Query Parameter:** `query` (e.g., "PPE", "chemical", "emergency")

**Response:**
```json
{
  "query": "PPE",
  "results": [
    {
      "document_id": "SOP-SAF-001",
      "title": "Chemical Handling Safety",
      "matched_field": "ppe_required",
      "matched_content": ["Chemical-resistant gloves", ...]
    }
  ]
}
```

**Think of it as:** A web service that lets you ask questions about processed documents

**Why we need it:**
- RESTful interface (standard API design)
- Managed service (no servers)
- Scalable (handles high traffic)
- Secure (IAM integration)

---

## 🔐 Security & IAM

### IAM Roles Needed

#### 1. Lambda Execution Role
**Permissions Required:**
```yaml
- s3:GetObject              # Read documents from S3
- bedrock:InvokeModel       # Call Bedrock AI
- dynamodb:PutItem          # Write to DynamoDB
- logs:CreateLogGroup       # CloudWatch logging
- logs:CreateLogStream
- logs:PutLogEvents
```

#### 2. API Gateway Execution Role
**Permissions Required:**
```yaml
- dynamodb:Query            # Query DynamoDB
- dynamodb:Scan             # Search DynamoDB
- logs:CreateLogGroup       # CloudWatch logging
```

#### 3. S3 Bucket Policy
**Allows Lambda to read documents**

---

## 📊 Data Flow (Step-by-Step)

### Flow 1: Document Upload & Processing

```
┌─────────────────────────────────────────────────────────────────┐
│ STEP 1: User Action                                              │
│ User uploads "__SAFETY_SOP.pdf" to S3 bucket                    │
└───────────────────────────┬─────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│ STEP 2: S3 Event Trigger                                         │
│ S3 emits event: "ObjectCreated" → Lambda receives notification  │
└───────────────────────────┬─────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│ STEP 3: Lambda Activation                                        │
│ Lambda wakes up with event data:                                │
│ { bucket: "doc-intelligence-uploads",                           │
│   key: "uploads/__SAFETY_SOP.pdf" }                             │
└───────────────────────────┬─────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│ STEP 4: Document Download                                        │
│ Lambda calls: s3.get_object(Bucket, Key)                        │
│ Downloads PDF bytes                                              │
└───────────────────────────┬─────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│ STEP 5: Text Extraction                                          │
│ Lambda extracts text from PDF using PyPDF2 or similar           │
│ Result: Full document text as string                            │
└───────────────────────────┬─────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│ STEP 6: Bedrock API Call                                         │
│ Lambda constructs prompt + document text                        │
│ Calls: bedrock.invoke_model(model, prompt)                     │
│ Waits for AI response (~3-5 seconds)                            │
└───────────────────────────┬─────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│ STEP 7: AI Processing                                            │
│ Bedrock (Claude) reads document                                 │
│ Extracts: summary, steps, PPE, warnings                         │
│ Returns: JSON response                                           │
└───────────────────────────┬─────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│ STEP 8: Parse AI Response                                        │
│ Lambda parses JSON from Bedrock                                 │
│ Adds metadata: timestamps, s3_key, processing_status            │
└───────────────────────────┬─────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│ STEP 9: Store in DynamoDB                                        │
│ Lambda calls: dynamodb.put_item(TableName, Item)               │
│ Document now searchable and queryable                           │
└───────────────────────────┬─────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│ STEP 10: Success!                                                │
│ Lambda logs success                                              │
│ Returns: { statusCode: 200, message: "Processed successfully" } │
└─────────────────────────────────────────────────────────────────┘
```

### Flow 2: Querying Results via API

```
User → API Gateway → Lambda (Query Function) → DynamoDB → Response
```

---

## 💰 Cost Estimation (Testing Phase)

**Assumptions:** Processing 100 documents during development

| Service | Usage | Cost |
|---------|-------|------|
| **S3** | 100 documents × 5MB each | ~$0.01/month |
| **Lambda** | 100 invocations × 5 seconds each | ~$0.10 |
| **Bedrock** | 100 docs × 10K tokens each | ~$0.25 |
| **DynamoDB** | 100 writes + 500 reads | ~$0.05 |
| **API Gateway** | 500 API calls | ~$0.02 |
| **Total** | | **~$0.43** |

**For production:** Costs scale linearly with usage (serverless pricing model)

---

## 🚀 Deployment Strategy

### Using AWS SAM (Infrastructure as Code)

**Single command deployment:**
```bash
sam build
sam deploy --guided
```

**What SAM creates:**
- S3 bucket with event notifications
- Lambda function with IAM role
- DynamoDB table
- API Gateway with endpoints
- CloudWatch log groups

**Benefits:**
- ✅ Repeatable deployments
- ✅ Version controlled (Git)
- ✅ Easy to tear down (sam delete)
- ✅ Environment variables managed
- ✅ Local testing (sam local invoke)

---

## 🧪 Testing Strategy

### Local Testing (Phase 3)
```bash
# Test Lambda locally with sample event
sam local invoke DocumentProcessorFunction -e events/sample-s3-event.json
```

### Integration Testing (Phase 6)
1. Upload test document to S3
2. Check CloudWatch logs for Lambda execution
3. Verify DynamoDB entry created
4. Query via API Gateway
5. Confirm correct data returned

### End-to-End Testing (Phase 7)
- Upload all 3 safety SOPs
- Verify all extracted correctly
- Test all API endpoints
- Check error handling

---

## 📈 Scalability Considerations

**Current Design Handles:**
- 1,000s of documents/hour (Lambda auto-scales)
- 10MB document size limit (Lambda payload limit)
- Concurrent processing (multiple uploads simultaneously)

**Future Enhancements:**
- Add SQS queue for very high volume
- Use Step Functions for complex workflows
- Add S3 versioning for document history
- Implement document deletion API

---

## ⚠️ Potential Issues & Solutions

### Issue 1: Large Documents (>10MB)
**Problem:** Lambda has 10MB invocation payload limit  
**Solution:** Read documents directly from S3 (streaming), don't pass as payload

### Issue 2: Slow AI Responses
**Problem:** Bedrock can take 5-10 seconds for large documents  
**Solution:** Set Lambda timeout to 5 minutes, add progress tracking

### Issue 3: Duplicate Processing
**Problem:** S3 might trigger Lambda multiple times for same upload  
**Solution:** Check DynamoDB before processing (idempotency)

### Issue 4: API Rate Limits
**Problem:** Bedrock has rate limits (requests/minute)  
**Solution:** Add retry logic with exponential backoff

---

## 🎯 Success Criteria

**We'll know the system works when:**
1. ✅ Upload document → Lambda triggers automatically
2. ✅ Bedrock extracts accurate structured data
3. ✅ DynamoDB stores results correctly
4. ✅ API returns queryable results
5. ✅ All 3 test SOPs processed successfully
6. ✅ Error handling works (bad uploads, timeouts)

---

## 📚 Architecture Decisions Log

### Why Serverless?
- No server management overhead
- Auto-scaling built-in
- Pay only for usage
- Fast iteration (deploy in minutes)

### Why Bedrock over OpenAI?
- AWS-native (simpler IAM)
- 10x cheaper for testing
- Data stays in AWS
- Better for portfolio (shows AWS expertise)

### Why DynamoDB over RDS?
- NoSQL better for flexible schema
- Faster for key-value lookups
- Serverless scaling
- Cheaper for small datasets

### Why API Gateway?
- Standard REST interface
- Managed service (no servers)
- Built-in rate limiting
- Easy CORS configuration

---

## 🔗 Related Documentation

- **Session Log:** `Day-01-Session-Log.md`
- **Extraction Examples:** `extraction-examples.md`
- **AI Workflow:** `ai-copilot-workflow.md`

---

## ✅ Next Steps

**Phase 2:** Project setup with SAM and PowerShell  
**Phase 3:** Implement S3 + Lambda trigger  
**Phase 4:** Integrate Bedrock AI  
**Phase 5:** Add DynamoDB storage  
**Phase 6:** Create API Gateway  
**Phase 7:** Test and document  

---

*This architecture is designed to be simple enough for a portfolio project while demonstrating real-world cloud engineering practices.*
